<?php
/**
 * ishare2 Image Store — backend API for the PNetLab GUI image downloader.
 *
 * Endpoints (all return JSON):
 *   ?action=catalog            → list QEMU + IOL images (id,name,size,installed)
 *   ?action=download type id   → start a background download, returns {job}
 *   ?action=status&job=ID      → progress of a running/finished job
 *
 * Data source: labhub.json catalog (GitHub release asset of ishare2-org/mirrors),
 * cached locally and refreshed every 6h. Downloads run via worker.sh as root
 * (the Apache user has NOPASSWD sudo on this box).
 */
error_reporting(E_ERROR | E_PARSE);
header('Content-Type: application/json');
header('Cache-Control: no-store');

$BASE        = __DIR__;
$CAT         = "$BASE/labhub.json";
$JOBS        = "$BASE/jobs";
$WORKER      = "$BASE/worker.sh";
$RELEASE_API = 'https://api.github.com/repos/ishare2-org/mirrors/releases/latest';

@mkdir($JOBS, 0777, true);

function out($x){ echo json_encode($x); exit; }
function fail($m, $code = 400){ http_response_code($code); echo json_encode(['error' => $m]); exit; }

function curl_get($url, $toFile = null){
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT      => 'pnetlab-ishare2-gui',
        CURLOPT_CONNECTTIMEOUT => 6,      // fail fast when the box is offline
        CURLOPT_TIMEOUT        => 120,
    ]);
    $fp = null;
    if ($toFile) { $fp = fopen($toFile, 'w'); curl_setopt($ch, CURLOPT_FILE, $fp); }
    else         { curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); }
    $r    = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($fp) fclose($fp);
    return [$code, $r];
}

// returns: 'cached' (fresh local copy) | 'fresh' (just downloaded) |
//          'stale' (refresh failed, serving old copy) | 'none' (no copy at all)
function refresh_catalog($CAT, $RELEASE_API){
    if (file_exists($CAT) && (time() - filemtime($CAT) < 21600)) return 'cached';
    [$c, $j] = curl_get($RELEASE_API);
    if ($c != 200) return file_exists($CAT) ? 'stale' : 'none';
    $rel = json_decode($j, true);
    $url = null;
    foreach (($rel['assets'] ?? []) as $a) {
        if (($a['name'] ?? '') === 'labhub.json') { $url = $a['browser_download_url']; break; }
    }
    if (!$url) return file_exists($CAT) ? 'stale' : 'none';
    [$c2, ] = curl_get($url, "$CAT.tmp");
    if ($c2 == 200 && @filesize("$CAT.tmp") > 1000) { rename("$CAT.tmp", $CAT); return 'fresh'; }
    @unlink("$CAT.tmp");
    return file_exists($CAT) ? 'stale' : 'none';
}

$action = $_GET['action'] ?? '';

if ($action === 'catalog') {
    $status = refresh_catalog($CAT, $RELEASE_API);
    if ($status === 'none' || !file_exists($CAT)) fail('catalog unavailable — check server internet access', 502);
    $d = json_decode(file_get_contents($CAT), true);
    if (!$d) fail('catalog parse error', 500);
    $res = ['updated' => $d['last_update'] ?? '', 'stale' => ($status === 'stale'), 'qemu' => [], 'iol' => []];
    foreach (['QEMU' => 'qemu', 'IOL' => 'iol'] as $k => $kk) {
        foreach (($d[$k] ?? []) as $e) {
            $ip = $e['metadata']['install_path'] ?? '';
            if ($kk === 'iol') {
                $fn = $e['files'][0]['filename'] ?? '';
                $installed = $fn && file_exists("/opt/unetlab/addons/iol/bin/$fn");
            } else {
                $installed = $ip && is_dir($ip) && count(glob(rtrim($ip, '/') . '/*')) > 0;
            }
            $res[$kk][] = [
                'id'        => (int)$e['id'],
                'name'      => $e['name'],
                'size'      => $e['metadata']['total_human_size'] ?? ($e['files'][0]['human_size'] ?? ''),
                'bytes'     => (int)($e['metadata']['total_size'] ?? 0),
                'installed' => (bool)$installed,
            ];
        }
    }
    out($res);
}

if ($action === 'download' || $action === 'delete') {
    $type = $_POST['type'] ?? $_GET['type'] ?? '';
    $id   = $_POST['id']   ?? $_GET['id']   ?? '';
    if (!in_array($type, ['qemu', 'iol', 'dynamips'], true)) fail('bad type');
    if (!ctype_digit((string)$id)) fail('bad id');
    $op  = ($action === 'delete') ? 'delete' : 'download';
    $job = bin2hex(random_bytes(8));                  // server-generated, 16 hex
    file_put_contents("$JOBS/$job.json", json_encode([
        'state' => ($op === 'delete' ? 'deleting' : 'queued'), 'pct' => 0,
        'type' => $type, 'id' => (int)$id, 'msg' => $op,
    ]));
    @chmod("$JOBS/$job.json", 0666);
    // detach as root; www-data has NOPASSWD sudo on this appliance
    $cmd = sprintf('sudo /bin/bash %s %s %d %s %s </dev/null >/dev/null 2>&1 &',
                   escapeshellarg($WORKER), escapeshellarg($type), (int)$id,
                   escapeshellarg($job), escapeshellarg($op));
    exec($cmd);
    out(['job' => $job]);
}

if ($action === 'status') {
    $job = $_GET['job'] ?? '';
    if (!preg_match('/^[a-f0-9]{16}$/', $job)) fail('bad job');
    $f = "$JOBS/$job.json";
    if (!file_exists($f)) fail('no such job', 404);
    echo file_get_contents($f);
    exit;
}

fail('unknown action');
