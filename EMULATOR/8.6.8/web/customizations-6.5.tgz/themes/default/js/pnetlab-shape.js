/**
 * pnetlab-shape.js — EVE-NG-style Custom Shape workflow for /legacy/topology.
 *
 * Replaces PNetLab's unused "Picture" object with a clean "Custom Shape" flow:
 *   • Add-object menu: "Picture" → "Custom Shape" (opens a white-glass modal)
 *   • Modal: pick square / rounded-square / circle + name, border, colors
 *   • Placed shape is a normal PNetLab text-object (#customShapeN), so it drags
 *     and persists for free; we add jQuery-UI resize on top.
 *   • Double-click (or right-click → Edit) a shape → EVE-style bottom
 *     "Object Style Editor" bar (name, z-index, border, colors, transparent,
 *     rotation), live-applied and persisted via editTextObject().
 *
 * Reuses PNetLab globals (functions.js): createTextObject, editTextObject,
 * getTextObjects, getTextObject, rgb2hex, getElementsAngle, App.topology.
 * Does NOT touch PNetLab's clunky form_edit_custom_shape.ejs / dead
 * action-customshapeadd path.
 *
 * Self-contained injected module (loaded by themes/default/index.html), same
 * pattern as pnetlab-node-form.js. White Apple-glass palette, accent #3c708a.
 */
(function () {
  'use strict';

  var ACCENT = '#3c708a';
  var DEFAULTS = { name: '', btype: 'solid', bwidth: 1, bcolor: '#000000', bgcolor: '#ffffff' };

  /* ── tiny helpers ─────────────────────────────────────────────────────── */
  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }
  function $q(sel, root) { return (root || document).querySelector(sel); }
  function clampHex(v, def) {
    v = (v || '').trim().replace(/^#/, '');
    return /^[0-9a-fA-F]{6}$/.test(v) ? '#' + v : def;
  }
  function debounce(fn, ms) {
    var t; return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); };
  }

  /* Decide a sensible drop position (canvas right-click point or centre). */
  function dropPoint() {
    var vp = window.jQuery ? jQuery('#lab-viewport') : null;
    var xy = vp && vp.data ? vp.data('contextClickXY') : null;
    if (xy && typeof xy.x === 'number') return { left: Math.max(0, xy.x - 70), top: Math.max(0, xy.y - 50) };
    return { left: Math.round(window.innerWidth * 0.45), top: Math.round(window.innerHeight * 0.4) };
  }

  /* ── next free customShape/text id (text objects share one id space) ───── */
  function nextId(cb) {
    if (typeof getTextObjects !== 'function') { cb(Date.now()); return; }
    getTextObjects().done(function (objs) {
      var i = 1; while (objs && objs['' + i] !== undefined) i++; cb(i);
    }).fail(function () { cb(Date.now()); });
  }

  /* ── build the shape's outerHTML (PNetLab #customShapeN contract) ──────── */
  function shapeHTML(id, o) {
    var W = o.shape === 'circle' ? 150 : 200, H = o.shape === 'circle' ? 150 : 140;
    var bw = Math.max(0, parseFloat(o.bwidth) || 0);
    var dash = o.btype === 'dashed' ? ' stroke-dasharray="8,5"' : '';
    var fill = o.bgcolor === 'none' ? 'none' : o.bgcolor;
    var svgChild;
    if (o.shape === 'circle') {
      svgChild = '<ellipse cx="' + (W / 2) + '" cy="' + (H / 2) + '" rx="' + (W / 2 - bw / 2) +
        '" ry="' + (H / 2 - bw / 2) + '" fill="' + fill + '" stroke="' + o.bcolor +
        '" stroke-width="' + bw + '"' + dash + '></ellipse>';
    } else {
      var r = o.shape === 'round' ? ' rx="14" ry="14"' : '';
      svgChild = '<rect x="' + (bw / 2) + '" y="' + (bw / 2) + '" width="' + (W - bw) +
        '" height="' + (H - bw) + '"' + r + ' fill="' + fill + '" stroke="' + o.bcolor +
        '" stroke-width="' + bw + '"' + dash + '></rect>';
    }
    var p = o.pos || { left: 0, top: 0 };
    return '<div id="customShape' + id + '" class="customShape context-menu resizable-content" ' +
      'data-path="' + id + '" data-pnq-shape="' + o.shape + '" name="' + (o.name || '') + '" ' +
      'style="position:absolute; display:block; top:' + p.top + 'px; left:' + p.left +
      'px; width:' + W + 'px; height:' + H + 'px; cursor:move; z-index:1000;">' +
      '<svg width="' + W + '" height="' + H + '">' + svgChild + '</svg></div>';
  }

  /* ════════════════════════════════════════════════════════════════════════
   *  1. ADD-SHAPE MODAL
   * ════════════════════════════════════════════════════════════════════════ */
  var modal = null;

  function previewSVG(shape) {
    if (shape === 'circle') return '<svg width="40" height="40"><ellipse cx="20" cy="20" rx="16" ry="16" fill="#fff" stroke="#1d1d1f" stroke-width="1.5"></ellipse></svg>';
    var r = shape === 'round' ? ' rx="8" ry="8"' : '';
    return '<svg width="40" height="40"><rect x="4" y="4" width="32" height="32"' + r + ' fill="#fff" stroke="#1d1d1f" stroke-width="1.5"></rect></svg>';
  }

  function colorRow(label, idbase, def) {
    return '<div class="pnq-shape-field">' +
      '<div class="pnq-shape-ftitle">' + label + '</div>' +
      '<div class="pnq-shape-color">' +
      '<span class="pnq-shape-hash">#</span>' +
      '<input type="text" class="pnq-shape-input pnq-shape-hex" id="' + idbase + '-hex" value="' + def.replace('#', '') + '" maxlength="6">' +
      '<input type="color" class="pnq-shape-swatch" id="' + idbase + '-clr" value="' + def + '">' +
      '</div></div>';
  }

  function openAddModal() {
    closeAddModal();
    modal = el('div', 'pnq-shape-overlay');
    modal.innerHTML =
      '<div class="pnq-shape-card" role="dialog">' +
        '<div class="pnq-shape-header">Custom Shape</div>' +
        '<div class="pnq-shape-body">' +
          '<div class="pnq-shape-group">' +
            '<div class="pnq-shape-gtitle">Shape Selection</div>' +
            '<div class="pnq-shape-picker">' +
              '<div class="pnq-shape-opt selected" data-shape="square">' + previewSVG('square') + '</div>' +
              '<div class="pnq-shape-opt" data-shape="round">' + previewSVG('round') + '</div>' +
              '<div class="pnq-shape-opt" data-shape="circle">' + previewSVG('circle') + '</div>' +
            '</div>' +
          '</div>' +
          '<div class="pnq-shape-group">' +
            '<div class="pnq-shape-gtitle">Shape Settings</div>' +
            '<div class="pnq-shape-field">' +
              '<div class="pnq-shape-ftitle">Name</div>' +
              '<input type="text" class="pnq-shape-input" id="pnq-shape-name" placeholder="Shape name">' +
            '</div>' +
            '<div class="pnq-shape-fields-row">' +
              '<div class="pnq-shape-field" style="flex:1 1 0">' +
                '<div class="pnq-shape-ftitle">Border Type</div>' +
                '<select class="pnq-shape-input" id="pnq-shape-btype"><option value="solid">solid</option><option value="dashed">dashed</option></select>' +
              '</div>' +
              '<div class="pnq-shape-field" style="flex:1 1 0">' +
                '<div class="pnq-shape-ftitle">Border Width</div>' +
                '<input type="number" min="0" max="40" class="pnq-shape-input" id="pnq-shape-bwidth" value="1">' +
              '</div>' +
            '</div>' +
            '<div class="pnq-shape-fields-row">' +
              colorRow('Border Color', 'pnq-shape-bc', DEFAULTS.bcolor) +
              colorRow('Background Color', 'pnq-shape-bg', DEFAULTS.bgcolor) +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="pnq-shape-actions">' +
          '<button type="button" class="pnq-shape-btn pnq-shape-add-btn">Add Shape</button>' +
          '<button type="button" class="pnq-shape-btn pnq-shape-cancel">Cancel</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(modal);

    // shape selection
    modal.querySelectorAll('.pnq-shape-opt').forEach(function (opt) {
      opt.addEventListener('click', function () {
        modal.querySelectorAll('.pnq-shape-opt').forEach(function (o) { o.classList.remove('selected'); });
        opt.classList.add('selected');
      });
    });
    // hex <-> swatch sync
    bindColorPair(modal, 'pnq-shape-bc');
    bindColorPair(modal, 'pnq-shape-bg');
    // actions
    modal.querySelector('.pnq-shape-add-btn').addEventListener('click', submitAdd);
    modal.querySelector('.pnq-shape-cancel').addEventListener('click', closeAddModal);
    modal.addEventListener('mousedown', function (e) { if (e.target === modal) closeAddModal(); });
    document.addEventListener('keydown', escClose);
    setTimeout(function () { var n = $q('#pnq-shape-name'); if (n) n.focus(); }, 60);
  }

  function bindColorPair(root, base) {
    var hex = $q('#' + base + '-hex', root), clr = $q('#' + base + '-clr', root);
    if (!hex || !clr) return;
    hex.addEventListener('input', function () { var v = clampHex(hex.value, null); if (v) clr.value = v; });
    clr.addEventListener('input', function () { hex.value = clr.value.replace('#', ''); });
  }
  function escClose(e) { if (e.key === 'Escape') closeAddModal(); }
  function closeAddModal() {
    if (modal) { modal.remove(); modal = null; document.removeEventListener('keydown', escClose); }
  }

  function submitAdd() {
    var shape = (modal.querySelector('.pnq-shape-opt.selected') || {}).getAttribute
      ? modal.querySelector('.pnq-shape-opt.selected').getAttribute('data-shape') : 'square';
    var o = {
      shape: shape,
      name: ($q('#pnq-shape-name').value || '').trim(),
      btype: $q('#pnq-shape-btype').value,
      bwidth: $q('#pnq-shape-bwidth').value,
      bcolor: clampHex($q('#pnq-shape-bc-hex').value, DEFAULTS.bcolor),
      bgcolor: clampHex($q('#pnq-shape-bg-hex').value, DEFAULTS.bgcolor),
      pos: dropPoint()
    };
    closeAddModal();
    nextId(function (id) {
      if (!o.name) o.name = 'shape ' + id;
      var data = shapeHTML(id, o);
      if (typeof createTextObject === 'function') {
        createTextObject({ data: data, name: o.name, type: 'shape' }).done(function () {
          if (typeof addMessage === 'function') addMessage('SUCCESS', 'Shape added.');
        }).fail(function (m) { if (typeof addMessage === 'function') addMessage('DANGER', m || 'Add shape failed'); });
      }
    });
  }

  /* ════════════════════════════════════════════════════════════════════════
   *  2. MENU SWAP  (Picture → Custom Shape)
   * ════════════════════════════════════════════════════════════════════════ */
  function swapMenu(menu) {
    var a = menu.querySelector('a.action-pictureadd');
    if (!a || a.dataset.pnqSwapped) return;
    a.dataset.pnqSwapped = '1';
    a.classList.remove('action-pictureadd');      // unhook PNetLab's picture handler
    a.classList.add('pnq-shape-add');
    a.innerHTML = '<svg width="13" height="13" style="margin-right:7px;vertical-align:-1px" viewBox="0 0 24 24">' +
      '<rect x="2" y="3" width="9" height="9" rx="1.5" fill="none" stroke="currentColor" stroke-width="2"></rect>' +
      '<circle cx="16.5" cy="16.5" r="5" fill="none" stroke="currentColor" stroke-width="2"></circle></svg>Custom Shape';
  }

  /* Trim a geometric shape's right-click menu to: Duplicate, Send To Back,
   * Send To Front, Edit, Delete. PNetLab's menu (built in lab.js) has no Edit
   * and adds two inline Rotate / 3D-Rotate inputs we don't want. */
  function tidyShapeMenu(menu) {
    if (menu.dataset.pnqTidied) return;
    var anchor = menu.querySelector('a[data-path].action-textobjectduplicate, a[data-path].action-textobjecttoback, a[data-path].action-textobjectdelete');
    if (!anchor) return;                         // not a text-object menu
    var id = anchor.getAttribute('data-path');
    if (!isGeomShape(id)) return;                // leave text objects untouched
    menu.dataset.pnqTidied = '1';
    // drop the inline Rotate + 3D-Rotate rows
    menu.querySelectorAll('.action-textrotate, .action-textskew').forEach(function (inp) {
      var li = inp.closest('li'); if (li) li.remove();
    });
    // inject an Edit item (before Delete) wired to our Object Style Editor
    if (!menu.querySelector('.action-textobjectedit')) {
      var del = menu.querySelector('.action-textobjectdelete');
      var delLi = del ? del.closest('li') : null;
      var li = el('li');
      li.innerHTML = '<a class="context-collapsible action-textobjectedit pnq-shape-edit" href="javascript:void(0)" data-path="' + id + '">' +
        '<i class="glyphicon glyphicon-edit"></i> Edit</a>';
      if (delLi) delLi.parentNode.insertBefore(li, delLi);
      else menu.querySelector('ul, .dropdown-menu, *').appendChild(li);
    }
  }

  // The add-object menu AND object menus are built by PNetLab/lab.js with no
  // hook for us; watch for the menu landing in the DOM and post-process it.
  var menuMo = new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      for (var j = 0; j < muts[i].addedNodes.length; j++) {
        var n = muts[i].addedNodes[j];
        if (n.nodeType !== 1) continue;
        var menu = (n.id === 'context-menu') ? n : (n.querySelector && n.querySelector('#context-menu'));
        if (menu) { swapMenu(menu); tidyShapeMenu(menu); }
      }
    }
  });
  if (document.body) menuMo.observe(document.body, { childList: true, subtree: true });
  else document.addEventListener('DOMContentLoaded', function () { menuMo.observe(document.body, { childList: true, subtree: true }); });

  // Open our modal (capture phase so nothing else fires first)
  document.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('.pnq-shape-add');
    if (t) {
      e.preventDefault(); e.stopImmediatePropagation();
      var cm = document.getElementById('context-menu'); if (cm) cm.remove();
      openAddModal();
    }
  }, true);

  /* ════════════════════════════════════════════════════════════════════════
   *  3. RESIZE  (visible modern ↘ handle; drag + position-persist already free)
   * ════════════════════════════════════════════════════════════════════════ */
  function geomOf(el) {
    var svg = el.querySelector('svg'); if (!svg) return null;
    var sh = svg.firstElementChild; if (!sh) return null;
    return { svg: svg, sh: sh, circle: sh.tagName.toLowerCase() === 'ellipse' };
  }
  function resizeShape(elm, w, h) {
    var g = geomOf(elm); if (!g) return;
    w = Math.max(30, Math.round(w)); h = Math.max(30, Math.round(h));
    var bw = parseFloat(g.sh.getAttribute('stroke-width')) || 0;
    elm.style.width = w + 'px'; elm.style.height = h + 'px';
    g.svg.setAttribute('width', w); g.svg.setAttribute('height', h);
    if (g.circle) {
      g.sh.setAttribute('cx', w / 2); g.sh.setAttribute('cy', h / 2);
      g.sh.setAttribute('rx', Math.max(0, w / 2 - bw / 2)); g.sh.setAttribute('ry', Math.max(0, h / 2 - bw / 2));
    } else {
      g.sh.setAttribute('width', Math.max(0, w - bw)); g.sh.setAttribute('height', Math.max(0, h - bw));
    }
  }
  function persistEl(elm) {
    if (typeof editTextObject !== 'function') return;
    var id = elm.id.replace('customShape', '');
    editTextObject(id, { data: elm.outerHTML, name: elm.getAttribute('name') || '' });
  }

  /* The resize handle is a DOM child of the shape, so PNetLab's own drag-stop
   * (and any save) would serialise it into the .unl. Wrap the text-object save
   * fns to strip it — keeps stored HTML clean regardless of who persists. */
  function stripHandles(html) {
    if (typeof html !== 'string') return html;
    if (html.indexOf('pnq-shape-resize') === -1 && html.indexOf('pnq-shape-near') === -1 &&
        html.indexOf('pnq-shape-rz-active') === -1 && html.indexOf('pnq-shape-editing') === -1 &&
        html.indexOf('data-pnq-wired') === -1) return html;
    var t = document.createElement('div'); t.innerHTML = html;
    t.querySelectorAll('.pnq-shape-resize').forEach(function (n) { n.remove(); });
    t.querySelectorAll('.pnq-shape-near, .pnq-shape-rz-active, .pnq-shape-editing').forEach(function (n) {
      n.classList.remove('pnq-shape-near', 'pnq-shape-rz-active', 'pnq-shape-editing');
    });
    t.querySelectorAll('[data-pnq-wired]').forEach(function (n) { n.removeAttribute('data-pnq-wired'); });
    return t.innerHTML;
  }
  function wrapSaver(fn, pick) {
    var orig = window[fn];
    if (typeof orig !== 'function' || orig.__pnqWrapped) return;
    window[fn] = function () { try { pick(arguments); } catch (e) {} return orig.apply(this, arguments); };
    window[fn].__pnqWrapped = true;
  }
  // functions.js may load after us — retry until the savers exist & are wrapped.
  function installSavers() {
    wrapSaver('editTextObject', function (a) { if (a[1] && a[1].data) a[1].data = stripHandles(a[1].data); });
    wrapSaver('createTextObject', function (a) { if (a[0] && a[0].data) a[0].data = stripHandles(a[0].data); });
    wrapSaver('editTextObjects', function (a) { var arr = a[0]; if (Array.isArray(arr)) arr.forEach(function (o) { if (o && o.data) o.data = stripHandles(o.data); }); });
    return (window.editTextObject && window.editTextObject.__pnqWrapped) &&
           (window.editTextObjects && window.editTextObjects.__pnqWrapped) &&
           (window.createTextObject && window.createTextObject.__pnqWrapped);
  }
  if (!installSavers()) {
    var _st = 0, _iv = setInterval(function () { if (installSavers() || ++_st > 60) clearInterval(_iv); }, 150);
  }

  // ── live resize driven by the handle ──
  var RZ = null;
  function onResizeMove(e) {
    if (!RZ) return;
    var z = (typeof getZoomLab === 'function' ? getZoomLab() : 100) / 100; if (!z) z = 1;
    resizeShape(RZ.elm, RZ.startW + (e.clientX - RZ.startX) / z, RZ.startH + (e.clientY - RZ.startY) / z);
  }
  function onResizeUp() {
    if (!RZ) return;
    var elm = RZ.elm; RZ = null;
    document.removeEventListener('mousemove', onResizeMove, true);
    document.removeEventListener('mouseup', onResizeUp, true);
    document.body.classList.remove('pnq-resizing');
    elm.classList.remove('pnq-shape-rz-active');
    persistEl(elm);
  }
  function startResize(e) {
    var elm = e.currentTarget.parentNode;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    RZ = { elm: elm, startX: e.clientX, startY: e.clientY,
           startW: parseFloat(elm.style.width) || elm.offsetWidth,
           startH: parseFloat(elm.style.height) || elm.offsetHeight };
    document.body.classList.add('pnq-resizing');
    elm.classList.add('pnq-shape-rz-active');
    document.addEventListener('mousemove', onResizeMove, true);
    document.addEventListener('mouseup', onResizeUp, true);
  }

  var ARROW = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" ' +
    'stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' +
    '<path d="M8 8 L16 16 M16 16 H9 M16 16 V9"></path></svg>';
  function wireShape(elm) {
    // mark on the JS object, NOT as a DOM attribute — an attribute would be
    // serialised into the saved lab, and after reload the shape would look
    // "already wired" and never get its handle back.
    if (elm.__pnqWired) return;
    elm.__pnqWired = true;
    elm.removeAttribute('data-pnq-wired');     // clean stale marker from old saves
    var h = elm.querySelector('.pnq-shape-resize');
    if (!h) { h = el('div', 'pnq-shape-resize'); h.innerHTML = ARROW; elm.appendChild(h); }
    h.addEventListener('mousedown', startResize, true);
  }
  function wireAllShapes() {
    document.querySelectorAll('.customShape[data-pnq-shape]').forEach(function (elm) {
      if (!elm.__pnqWired) wireShape(elm);
    });
  }
  // Re-wire after every topology redraw (printTopology rebuilds the DOM).
  var mo = new MutationObserver(debounce(wireAllShapes, 80));
  function startObserver() {
    var vp = document.getElementById('lab-viewport') || document.body;
    mo.observe(vp, { childList: true, subtree: true });
    wireAllShapes();
  }
  if (document.readyState !== 'loading') startObserver();
  else document.addEventListener('DOMContentLoaded', startObserver);

  // Reveal the handle when the cursor reaches a shape's boundary. Driven from
  // JS (not CSS :hover) because the canvas has overlay layers that can swallow
  // :hover on the shape; proximity-testing the bounding box is reliable.
  var _track = false;
  document.addEventListener('mousemove', function (e) {
    if (RZ || _track) return;
    _track = true;
    var x = e.clientX, y = e.clientY, m = 16;
    requestAnimationFrame(function () {
      _track = false;
      document.querySelectorAll('.customShape[data-pnq-shape]').forEach(function (elm) {
        var r = elm.getBoundingClientRect();
        var near = x >= r.left - m && x <= r.right + m && y >= r.top - m && y <= r.bottom + m;
        elm.classList.toggle('pnq-shape-near', near);
      });
    });
  }, true);

  /* ════════════════════════════════════════════════════════════════════════
   *  4. ON-CANVAS OBJECT STYLE EDITOR  (EVE bottom bar)
   * ════════════════════════════════════════════════════════════════════════ */
  var editor = null, editorId = null;

  function isGeomShape(id) {
    var e = document.getElementById('customShape' + id);
    return e && e.getAttribute('data-pnq-shape');
  }

  function openStyleEditor(id) {
    if (!isGeomShape(id)) return;
    closeStyleEditor();
    editorId = id;
    var elm = document.getElementById('customShape' + id);
    var g = geomOf(elm);
    var name = elm.getAttribute('name') || '';
    var z = (parseInt(elm.style.zIndex, 10) || 1000) - 1000;
    var fill = g.sh.getAttribute('fill') || '#ffffff';
    var transparent = (fill === 'none' || fill === 'transparent');
    var bgHex = transparent ? 'ffffff' : (rgb2hexSafe(fill).replace('#', ''));
    var bcHex = rgb2hexSafe(g.sh.getAttribute('stroke') || '#000000').replace('#', '');
    var bw = parseFloat(g.sh.getAttribute('stroke-width')) || 0;
    var dashed = !!g.sh.getAttribute('stroke-dasharray');
    var rot = (typeof getElementsAngle === 'function') ? (getElementsAngle('#customShape' + id) || 0) : 0;

    editor = el('div', 'pnq-objstyle');
    editor.innerHTML =
      '<div class="pnq-objstyle-title">Object Style Editor</div>' +
      '<div class="pnq-objstyle-fields">' +
        block('Name', '<input type="text" class="pnq-objstyle-input" id="pnq-os-name" value="' + escAttr(name) + '" style="width:150px">') +
        block('Z-Index', '<input type="range" min="-20" max="20" id="pnq-os-zr" value="' + z + '" style="width:90px">' +
                          '<input type="number" min="-20" max="20" class="pnq-objstyle-input" id="pnq-os-z" value="' + z + '" style="width:60px">') +
        block('Border Width', '<input type="number" min="0" max="40" class="pnq-objstyle-input" id="pnq-os-bw" value="' + bw + '" style="width:64px">') +
        block('Border Type', '<select class="pnq-objstyle-input" id="pnq-os-bt"><option value="solid"' + (dashed ? '' : ' selected') + '>solid</option><option value="dashed"' + (dashed ? ' selected' : '') + '>dashed</option></select>') +
        block('Border Color', colorMini('pnq-os-bc', bcHex)) +
        block('Background', colorMini('pnq-os-bg', bgHex)) +
        block('Transparent', '<label class="pnq-objstyle-toggle"><input type="checkbox" id="pnq-os-tr"' + (transparent ? ' checked' : '') + '><span></span></label>') +
        block('Rotation', '<input type="number" min="0" max="360" class="pnq-objstyle-input" id="pnq-os-rot" value="' + Math.round(rot) + '" style="width:64px">') +
      '</div>' +
      '<button type="button" class="pnq-objstyle-close" title="Close">&times;</button>';
    document.body.appendChild(editor);

    bindColorPair(editor, 'pnq-os-bc');
    bindColorPair(editor, 'pnq-os-bg');
    var zr = $q('#pnq-os-zr', editor), zn = $q('#pnq-os-z', editor);
    zr.addEventListener('input', function () { zn.value = zr.value; applyEditor(); });
    zn.addEventListener('input', function () { zr.value = zn.value; applyEditor(); });
    ['pnq-os-name', 'pnq-os-bw', 'pnq-os-bt', 'pnq-os-bc-hex', 'pnq-os-bc-clr',
     'pnq-os-bg-hex', 'pnq-os-bg-clr', 'pnq-os-tr', 'pnq-os-rot'].forEach(function (i) {
      var node = $q('#' + i, editor); if (node) node.addEventListener('input', applyEditor);
    });
    $q('#pnq-os-tr', editor).addEventListener('change', applyEditor);
    editor.querySelector('.pnq-objstyle-close').addEventListener('click', closeStyleEditor);
    elm.classList.add('pnq-shape-editing');
  }

  function colorMini(base, hex) {
    return '<span class="pnq-objstyle-color"><span class="pnq-shape-hash">#</span>' +
      '<input type="text" class="pnq-objstyle-input pnq-objstyle-hex" id="' + base + '-hex" value="' + hex + '" maxlength="6">' +
      '<input type="color" class="pnq-objstyle-swatch" id="' + base + '-clr" value="#' + hex + '"></span>';
  }
  function block(label, inner) {
    return '<div class="pnq-objstyle-block"><div class="pnq-objstyle-blabel">' + label + '</div>' +
      '<div class="pnq-objstyle-brow">' + inner + '</div></div>';
  }
  function escAttr(s) { return (s || '').replace(/"/g, '&quot;'); }
  function rgb2hexSafe(c) {
    if (!c) return '#000000';
    if (c.charAt(0) === '#') return c.length === 7 ? c : '#000000';
    if (typeof rgb2hex === 'function') { try { return rgb2hex(c); } catch (e) {} }
    return '#000000';
  }

  var applyEditor = debounce(function () {
    if (!editor || editorId == null) return;
    var elm = document.getElementById('customShape' + editorId);
    if (!elm) { closeStyleEditor(); return; }
    var g = geomOf(elm); if (!g) return;
    var bw = Math.max(0, parseFloat($q('#pnq-os-bw', editor).value) || 0);
    var bt = $q('#pnq-os-bt', editor).value;
    var bc = clampHex($q('#pnq-os-bc-hex', editor).value, '#000000');
    var transparent = $q('#pnq-os-tr', editor).checked;
    var bg = transparent ? 'none' : clampHex($q('#pnq-os-bg-hex', editor).value, '#ffffff');
    var z = parseInt($q('#pnq-os-z', editor).value, 10) || 0;
    var rot = parseInt($q('#pnq-os-rot', editor).value, 10) || 0;
    var name = $q('#pnq-os-name', editor).value;

    g.sh.setAttribute('fill', bg);
    g.sh.setAttribute('stroke', bc);
    g.sh.setAttribute('stroke-width', bw);
    if (bt === 'dashed') g.sh.setAttribute('stroke-dasharray', '8,5'); else g.sh.removeAttribute('stroke-dasharray');
    // keep geometry consistent with new border width
    var w = parseFloat(g.svg.getAttribute('width')), h = parseFloat(g.svg.getAttribute('height'));
    if (g.circle) { g.sh.setAttribute('rx', Math.max(0, w / 2 - bw / 2)); g.sh.setAttribute('ry', Math.max(0, h / 2 - bw / 2)); }
    else { g.sh.setAttribute('x', bw / 2); g.sh.setAttribute('y', bw / 2); g.sh.setAttribute('width', Math.max(0, w - bw)); g.sh.setAttribute('height', Math.max(0, h - bw)); }
    elm.style.zIndex = 1000 + z;
    elm.setAttribute('name', name);
    var base = (elm.style.transform || '').replace(/rotate\([^)]*\)/g, '').trim();
    elm.style.transform = (base + ' rotate(' + rot + 'deg)').trim();

    persistEl(elm);
  }, 250);

  function closeStyleEditor() {
    if (editorId != null) {
      var e = document.getElementById('customShape' + editorId);
      if (e) e.classList.remove('pnq-shape-editing');
    }
    if (editor) { editor.remove(); editor = null; }
    editorId = null;
  }

  // open editor: double-click a geometric shape
  document.addEventListener('dblclick', function (e) {
    var s = e.target.closest && e.target.closest('.customShape[data-pnq-shape]');
    if (s) { e.preventDefault(); e.stopPropagation(); openStyleEditor(s.id.replace('customShape', '')); }
  }, true);

  // open editor: intercept right-click → Edit for geometric shapes only
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('.action-textobjectedit');
    if (!a) return;
    var id = a.getAttribute('data-path');
    if (isGeomShape(id)) {
      e.preventDefault(); e.stopImmediatePropagation();
      var cm = document.getElementById('context-menu'); if (cm) cm.remove();
      openStyleEditor(id);
    }
  }, true);

  /* Duplicate / Send To Back / Send To Front: PNetLab's handlers call
   * $shape.resizable("destroy") — which throws on our shapes (we don't use
   * jQuery-UI resizable), aborting the action. Reimplement cleanly for our
   * geometric shapes. (Delete works natively, so it's left untouched.) */
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest(
      '.action-textobjectduplicate, .action-textobjecttoback, .action-textobjecttofront');
    if (!a) return;
    var id = a.getAttribute('data-path');
    if (!isGeomShape(id)) return;          // leave text objects to PNetLab
    e.preventDefault(); e.stopImmediatePropagation();
    var cm = document.getElementById('context-menu'); if (cm) cm.remove();
    var elm = document.getElementById('customShape' + id);
    var z = parseInt(elm.style.zIndex, 10) || 1000;

    if (a.classList.contains('action-textobjecttoback')) {
      elm.style.zIndex = z - 1; persistEl(elm);
    } else if (a.classList.contains('action-textobjecttofront')) {
      elm.style.zIndex = z + 1; persistEl(elm);
    } else {                                // duplicate
      nextId(function (nid) {
        var tmp = el('div'); tmp.innerHTML = stripHandles(elm.outerHTML);
        var d = tmp.firstElementChild;
        d.id = 'customShape' + nid;
        d.setAttribute('data-path', nid);
        d.style.top = ((parseFloat(elm.style.top) || 0) + 30) + 'px';
        d.style.left = ((parseFloat(elm.style.left) || 0) + 30) + 'px';
        var name = (elm.getAttribute('name') || 'shape') + ' copy';
        d.setAttribute('name', name);
        if (typeof createTextObject === 'function') {
          createTextObject({ data: d.outerHTML, name: name, type: 'shape' }).fail(function (m) {
            if (typeof addMessage === 'function') addMessage('DANGER', m || 'Duplicate failed');
          });
        }
      });
    }
  }, true);

  /* ════════════════════════════════════════════════════════════════════════
   *  5. MULTI-DELETE FIX  (free-select → Delete also removes shapes)
   * ════════════════════════════════════════════════════════════════════════
   * PNetLab's free-select delete (actions.js #deleteText) loops `.ui-selected`
   * and only deletes `.customText` — our shapes are `.customShape` (no
   * customText class), so a multi-select Delete silently skipped them. On the
   * confirm click we snapshot the selected shape ids (capture phase, before
   * PNetLab mutates the DOM), then delete them + repaint after PNetLab's own
   * pass. Single (non-free-select) delete is left entirely to PNetLab. */
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('#deleteText');
    if (!b) return;
    var vp = document.getElementById('lab-viewport');
    if (!vp || !vp.classList.contains('freeSelectMode')) return;
    if (typeof deleteTextObject !== 'function') return;
    var ids = [];
    document.querySelectorAll('.ui-selected.customShape:not(.customText)').forEach(function (s) {
      var id = s.getAttribute('data-path'); if (id != null && id !== '') ids.push(id);
    });
    if (!ids.length) return;                 // nothing of ours selected → PNetLab handles it
    // defer so PNetLab's own delete + printTopology runs first, then remove ours
    setTimeout(function () {
      var ps = ids.map(function (id) { return deleteTextObject(id); });
      function reprint() { if (window.App && App.topology) App.topology.printTopology(); }
      if (window.jQuery) jQuery.when.apply(jQuery, ps).always(reprint); else reprint();
    }, 40);
  }, true);

})();
