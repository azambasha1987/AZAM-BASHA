/**
 * pnetlab-text.js — EVE-NG-style Text workflow for /legacy/topology.
 *
 * Replaces PNetLab's bulky "click Text → big CKEditor toolbar modal" flow with
 * EVE-NG's clean Text object:
 *   • Add-object menu "Text" → drops a "New Text" object directly on the canvas
 *     (no modal), as a normal PNetLab text-object (#customTextN) so it drags and
 *     persists for free.
 *   • Right-click a text → trimmed menu: Duplicate · Send To Back · Send To
 *     Front · Edit · Delete (matches EVE).
 *   • Double-click a text → edit content INLINE (contenteditable) with a small
 *     EVE-style floating formatting toolbar (bold/italic/underline/font-size/
 *     color/align via execCommand). Commit on click-away / Esc → editTextObject.
 *   • Right-click → Edit → EVE "Text Style Editor" bottom bar (Name, Rotation,
 *     Z-Index) with Save / Cancel.
 *
 * Reuses PNetLab globals (functions.js): createTextObject, editTextObject,
 * editTextObjects, getTextObjects, getElementsAngle, addMessage. Does NOT touch
 * PNetLab core JS — all via event delegation + DOM post-processing, same
 * pattern as pnetlab-shape.js. White Apple-glass palette, accent #3c708a.
 *
 * Self-contained injected module (loaded by themes/default/index.html).
 */
(function () {
  'use strict';

  var ACCENT = '#3c708a';
  var DEFAULT_HTML = '<p>New Text</p>';

  /* ── tiny helpers (same idiom as pnetlab-shape.js) ────────────────────── */
  function el(tag, cls, html) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    return e;
  }
  function $q(sel, root) { return (root || document).querySelector(sel); }
  function debounce(fn, ms) {
    var t; return function () { var a = arguments, c = this; clearTimeout(t); t = setTimeout(function () { fn.apply(c, a); }, ms); };
  }
  function escAttr(s) { return (s || '').replace(/"/g, '&quot;'); }

  /* drop position: canvas right-click point, else viewport centre */
  function dropPoint() {
    var vp = window.jQuery ? jQuery('#lab-viewport') : null;
    var xy = vp && vp.data ? vp.data('contextClickXY') : null;
    if (xy && typeof xy.x === 'number') return { left: Math.max(0, xy.x - 30), top: Math.max(0, xy.y - 12) };
    return { left: Math.round(window.innerWidth * 0.45), top: Math.round(window.innerHeight * 0.4) };
  }

  /* next free text/shape id (text objects share one id space with shapes) */
  function nextId(cb) {
    if (typeof getTextObjects !== 'function') { cb(Date.now()); return; }
    getTextObjects().done(function (objs) {
      var i = 1; while (objs && objs['' + i] !== undefined) i++; cb(i);
    }).fail(function () { cb(Date.now()); });
  }

  function isText(id) {
    var e = document.getElementById('customText' + id);
    return !!e && !e.getAttribute('data-pnq-shape');
  }

  /* ── build the text object's outerHTML (PNetLab #customTextN contract) ─── */
  function textHTML(id, inner, pos, z, name) {
    var p = pos || { left: 0, top: 0 };
    return '<div id="customText' + id + '" class="customShape customText context-menu ck-content" data-path="' + id + '" ' +
      'name="' + escAttr(name || 'New Text') + '" ' +
      'style="position:absolute; display:inline-block; top:' + p.top + 'px; left:' + p.left +
      'px; cursor:move; z-index:' + (z || 1000) + ';">' + (inner || DEFAULT_HTML) + '</div>';
  }

  /* ════════════════════════════════════════════════════════════════════════
   *  1. DIRECT DROP  (Text menu item → place "New Text", no CKEditor modal)
   * ════════════════════════════════════════════════════════════════════════ */
  function addText() {
    var pos = dropPoint();
    nextId(function (id) {
      var data = textHTML(id, DEFAULT_HTML, pos, 1000, 'New Text');
      if (typeof createTextObject !== 'function') return;
      createTextObject({ data: data, name: 'New Text', type: 'text' }).done(function () {
        if (typeof addMessage === 'function') addMessage('SUCCESS', 'Text added.');
      }).fail(function (m) { if (typeof addMessage === 'function') addMessage('DANGER', m || 'Add text failed'); });
    });
  }

  // Block PNetLab's CKEditor-modal handler (bound on document, bubble phase) and
  // place the text directly. Capture + stopImmediatePropagation, same trick as
  // pnetlab-shape.js uses for .pnq-shape-add.
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('.action-textadd');
    if (!a) return;
    e.preventDefault(); e.stopImmediatePropagation();
    var cm = document.getElementById('context-menu'); if (cm) cm.remove();
    addText();
  }, true);

  /* ════════════════════════════════════════════════════════════════════════
   *  2. RIGHT-CLICK MENU  (tidy text menu → Duplicate/Back/Front/Edit/Delete)
   * ════════════════════════════════════════════════════════════════════════ */
  function tidyTextMenu(menu) {
    if (menu.dataset.pnqTextTidied) return;
    var anchor = menu.querySelector(
      'a[data-path].action-textobjectduplicate, a[data-path].action-textobjecttoback, a[data-path].action-textobjecttofront, a[data-path].action-textobjectdelete');
    if (!anchor) return;                        // not a text-object menu
    var id = anchor.getAttribute('data-path');
    if (!isText(id)) return;                    // shape menu → leave to pnetlab-shape.js
    menu.dataset.pnqTextTidied = '1';
    // drop the inline Rotate + 3D-Rotate rows (replaced by the Style Editor)
    menu.querySelectorAll('.action-textrotate, .action-textskew').forEach(function (inp) {
      var li = inp.closest('li'); if (li) li.remove();
    });
    // inject an Edit item (before Delete) wired to our Text Style Editor
    if (!menu.querySelector('.action-textobjectedit')) {
      var del = menu.querySelector('.action-textobjectdelete');
      var delLi = del ? del.closest('li') : null;
      var li = el('li');
      li.innerHTML = '<a class="context-collapsible action-textobjectedit pnq-text-edit" href="javascript:void(0)" data-path="' + id + '">' +
        '<i class="glyphicon glyphicon-edit"></i> Edit</a>';
      if (delLi) delLi.parentNode.insertBefore(li, delLi);
      else (menu.querySelector('ul, .dropdown-menu') || menu).appendChild(li);
    }
  }

  // PNetLab/lab.js builds the context menu with no hook for us; watch for it.
  var menuMo = new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      for (var j = 0; j < muts[i].addedNodes.length; j++) {
        var n = muts[i].addedNodes[j];
        if (n.nodeType !== 1) continue;
        var menu = (n.id === 'context-menu') ? n : (n.querySelector && n.querySelector('#context-menu'));
        if (menu) tidyTextMenu(menu);
      }
    }
  });
  if (document.body) menuMo.observe(document.body, { childList: true, subtree: true });
  else document.addEventListener('DOMContentLoaded', function () { menuMo.observe(document.body, { childList: true, subtree: true }); });

  /* ════════════════════════════════════════════════════════════════════════
   *  3. KEEP STORED HTML CLEAN  (strip transient edit attrs before any save)
   * ════════════════════════════════════════════════════════════════════════ */
  function stripText(html) {
    if (typeof html !== 'string') return html;
    if (html.indexOf('contenteditable') === -1 && html.indexOf('pnq-text-editing') === -1) return html;
    var t = document.createElement('div'); t.innerHTML = html;
    t.querySelectorAll('[contenteditable]').forEach(function (n) { n.removeAttribute('contenteditable'); });
    t.querySelectorAll('.pnq-text-editing').forEach(function (n) { n.classList.remove('pnq-text-editing'); });
    return t.innerHTML;
  }
  // functions.js (and pnetlab-shape.js) may wrap these too — use a distinct
  // marker so our wrapper chains on top instead of being skipped.
  function wrapSaver(fn, pick) {
    var orig = window[fn];
    if (typeof orig !== 'function' || orig.__pnqTextWrapped) return;
    window[fn] = function () { try { pick(arguments); } catch (e) {} return orig.apply(this, arguments); };
    window[fn].__pnqTextWrapped = true;
  }
  function installSavers() {
    wrapSaver('editTextObject', function (a) { if (a[1] && a[1].data) a[1].data = stripText(a[1].data); });
    wrapSaver('createTextObject', function (a) { if (a[0] && a[0].data) a[0].data = stripText(a[0].data); });
    wrapSaver('editTextObjects', function (a) { var arr = a[0]; if (Array.isArray(arr)) arr.forEach(function (o) { if (o && o.data) o.data = stripText(o.data); }); });
    return (window.editTextObject && window.editTextObject.__pnqTextWrapped) &&
           (window.createTextObject && window.createTextObject.__pnqTextWrapped) &&
           (window.editTextObjects && window.editTextObjects.__pnqTextWrapped);
  }
  if (!installSavers()) {
    var _st = 0, _iv = setInterval(function () { if (installSavers() || ++_st > 60) clearInterval(_iv); }, 150);
  }

  function persistText(elm) {
    if (typeof editTextObject !== 'function') return;
    var id = elm.id.replace('customText', '');
    editTextObject(id, { data: elm.outerHTML, name: elm.getAttribute('name') || '' });
  }

  /* ════════════════════════════════════════════════════════════════════════
   *  4. INLINE CONTENT EDIT  (double-click) + floating formatting toolbar
   * ════════════════════════════════════════════════════════════════════════ */
  var editEl = null, toolbar = null, savedRange = null;

  function enterEdit(elm) {
    if (editEl === elm) return;
    commitEdit();                                 // close any other open editor
    editEl = elm;
    elm.classList.add('pnq-text-editing');
    elm.setAttribute('contenteditable', 'true');
    elm.focus();
    // select all so typing replaces the placeholder
    try {
      var r = document.createRange(); r.selectNodeContents(elm);
      var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r);
    } catch (e) {}
    buildToolbar();
    positionToolbar();
    // suppress katavorio drag while editing (capture, no preventDefault so the
    // caret + text selection still work)
    elm.addEventListener('mousedown', stopDrag, true);
  }
  function stopDrag(e) { e.stopPropagation(); }

  function commitEdit() {
    if (!editEl) return;
    var elm = editEl; editEl = null;
    elm.removeEventListener('mousedown', stopDrag, true);
    elm.removeAttribute('contenteditable');
    elm.classList.remove('pnq-text-editing');
    if (toolbar) { toolbar.remove(); toolbar = null; }
    savedRange = null;
    // drop the text-selection highlight + focus, else the blue select shading
    // sticks on the (now non-editable) text until a page reload.
    try { var sel = window.getSelection(); if (sel) sel.removeAllRanges(); } catch (e) {}
    if (typeof elm.blur === 'function') elm.blur();
    // empty content → restore placeholder so the object stays selectable
    if (!elm.textContent.trim()) elm.innerHTML = DEFAULT_HTML;
    persistText(elm);
  }

  // remember the live selection so native controls (color/select) can restore it
  document.addEventListener('selectionchange', function () {
    if (!editEl) return;
    var sel = window.getSelection();
    if (sel && sel.rangeCount && editEl.contains(sel.anchorNode)) savedRange = sel.getRangeAt(0).cloneRange();
  });
  function restoreRange() {
    if (!savedRange) return;
    var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(savedRange);
  }

  function exec(cmd, val) {
    editEl.focus(); restoreRange();
    try { document.execCommand('styleWithCSS', false, true); } catch (e) {}
    document.execCommand(cmd, false, val || null);
    savedRange = (window.getSelection().rangeCount) ? window.getSelection().getRangeAt(0).cloneRange() : savedRange;
  }
  // px font-size via the execCommand('fontSize') + rewrite-<font> trick
  function setFontSize(px) {
    editEl.focus(); restoreRange();
    document.execCommand('fontSize', false, '7');
    editEl.querySelectorAll('font[size="7"]').forEach(function (f) {
      f.removeAttribute('size'); f.style.fontSize = px + 'px';
    });
  }

  var TB = [
    { cmd: 'bold', label: 'B', style: 'font-weight:700', title: 'Bold' },
    { cmd: 'italic', label: 'I', style: 'font-style:italic', title: 'Italic' },
    { cmd: 'underline', label: 'U', style: 'text-decoration:underline', title: 'Underline' }
  ];
  var ALIGN = [
    { cmd: 'justifyLeft', svg: 'M3 5h18M3 10h12M3 15h18M3 20h12', title: 'Align left' },
    { cmd: 'justifyCenter', svg: 'M3 5h18M6 10h12M3 15h18M6 20h12', title: 'Align center' },
    { cmd: 'justifyRight', svg: 'M3 5h18M9 10h12M3 15h18M9 20h12', title: 'Align right' }
  ];
  function buildToolbar() {
    toolbar = el('div', 'pnq-text-toolbar');
    var html = '';
    TB.forEach(function (b) {
      html += '<button type="button" class="pnq-text-tbtn" data-cmd="' + b.cmd + '" title="' + b.title + '" style="' + b.style + '">' + b.label + '</button>';
    });
    html += '<span class="pnq-text-sep"></span>';
    html += '<select class="pnq-text-size" title="Font size">' +
      ['12', '14', '16', '18', '24', '32', '48'].map(function (s) { return '<option value="' + s + '"' + (s === '16' ? ' selected' : '') + '>' + s + '</option>'; }).join('') +
      '</select>';
    html += '<label class="pnq-text-clr" title="Text color"><span class="pnq-text-clr-A">A</span><input type="color" value="#1d1d1f"></label>';
    html += '<span class="pnq-text-sep"></span>';
    ALIGN.forEach(function (a) {
      html += '<button type="button" class="pnq-text-tbtn pnq-text-icon" data-cmd="' + a.cmd + '" title="' + a.title + '">' +
        '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="' + a.svg + '"/></svg></button>';
    });
    toolbar.innerHTML = html;
    document.body.appendChild(toolbar);

    // keep selection: buttons must not steal focus from the editable
    toolbar.addEventListener('mousedown', function (e) {
      if (e.target.closest('input, select')) return;   // native controls need focus
      e.preventDefault();
    });
    toolbar.querySelectorAll('.pnq-text-tbtn').forEach(function (btn) {
      btn.addEventListener('click', function (e) { e.preventDefault(); exec(btn.getAttribute('data-cmd')); });
    });
    toolbar.querySelector('.pnq-text-size').addEventListener('change', function () { setFontSize(this.value); editEl.focus(); });
    toolbar.querySelector('.pnq-text-clr input').addEventListener('input', function () { exec('foreColor', this.value); });
  }
  function positionToolbar() {
    if (!toolbar || !editEl) return;
    var r = editEl.getBoundingClientRect();
    var tb = toolbar.getBoundingClientRect();
    var top = r.top - tb.height - 8;
    if (top < 8) top = r.bottom + 8;              // flip below if near the top
    var left = Math.max(8, Math.min(r.left, window.innerWidth - tb.width - 8));
    toolbar.style.top = top + 'px';
    toolbar.style.left = left + 'px';
  }

  // open inline edit on double-click; capture+stop blocks PNetLab's old modal
  document.addEventListener('dblclick', function (e) {
    var t = e.target.closest && e.target.closest('.customText');
    if (!t || t.getAttribute('data-pnq-shape')) return;
    if (typeof LOCK !== 'undefined' && LOCK == 1) return;
    e.preventDefault(); e.stopImmediatePropagation();
    enterEdit(t);
  }, true);

  // commit when clicking outside the editable + toolbar
  document.addEventListener('mousedown', function (e) {
    if (!editEl) return;
    if (editEl.contains(e.target)) return;
    if (toolbar && toolbar.contains(e.target)) return;
    commitEdit();
  }, true);
  // Esc commits
  document.addEventListener('keydown', function (e) {
    if (editEl && e.key === 'Escape') { e.preventDefault(); commitEdit(); }
  }, true);
  window.addEventListener('scroll', function () { positionToolbar(); }, true);

  /* ════════════════════════════════════════════════════════════════════════
   *  5. TEXT STYLE EDITOR  (EVE bottom bar: Name / Rotation / Z-Index)
   * ════════════════════════════════════════════════════════════════════════ */
  var editor = null, editorId = null, orig = null;

  function getRotation(id) {
    if (typeof getElementsAngle === 'function') { try { return getElementsAngle('#customText' + id) || 0; } catch (e) {} }
    return 0;
  }
  function applyRotation(elm, deg) {
    var base = (elm.style.transform || '').replace(/rotate\([^)]*\)/g, '').trim();
    elm.style.transform = (base + ' rotate(' + deg + 'deg)').trim();
    elm.style.transformOrigin = 'center center';
  }

  function openStyleEditor(id) {
    if (!isText(id)) return;
    commitEdit();
    closeStyleEditor();
    editorId = id;
    var elm = document.getElementById('customText' + id);
    var name = elm.getAttribute('name') || '';
    var z = (parseInt(elm.style.zIndex, 10) || 1000) - 1000;
    var rot = Math.round(getRotation(id));
    orig = { name: name, z: z, rot: rot };

    editor = el('div', 'pnq-textstyle');
    editor.innerHTML =
      '<div class="pnq-textstyle-title">Text Style Editor</div>' +
      '<div class="pnq-textstyle-fields">' +
        block('Text Name', '<input type="text" class="pnq-textstyle-input" id="pnq-ts-name" value="' + escAttr(name) + '" style="width:170px">') +
        block('Rotation', '<input type="range" min="-180" max="180" id="pnq-ts-rotr" value="' + rot + '" style="width:120px">' +
                          '<input type="number" min="-180" max="180" class="pnq-textstyle-input" id="pnq-ts-rot" value="' + rot + '" style="width:64px">') +
        block('Z-Index', '<input type="range" min="-20" max="20" id="pnq-ts-zr" value="' + z + '" style="width:120px">' +
                         '<input type="number" min="-20" max="20" class="pnq-textstyle-input" id="pnq-ts-z" value="' + z + '" style="width:64px">') +
      '</div>' +
      '<div class="pnq-textstyle-actions">' +
        '<button type="button" class="pnq-textstyle-btn pnq-textstyle-save">Save</button>' +
        '<button type="button" class="pnq-textstyle-btn pnq-textstyle-cancel">Cancel</button>' +
      '</div>';
    document.body.appendChild(editor);

    var rotR = $q('#pnq-ts-rotr', editor), rotN = $q('#pnq-ts-rot', editor);
    var zR = $q('#pnq-ts-zr', editor), zN = $q('#pnq-ts-z', editor);
    rotR.addEventListener('input', function () { rotN.value = rotR.value; applyEditor(); });
    rotN.addEventListener('input', function () { rotR.value = rotN.value; applyEditor(); });
    zR.addEventListener('input', function () { zN.value = zR.value; applyEditor(); });
    zN.addEventListener('input', function () { zR.value = zN.value; applyEditor(); });
    $q('#pnq-ts-name', editor).addEventListener('input', applyEditor);
    editor.querySelector('.pnq-textstyle-save').addEventListener('click', saveEditor);
    editor.querySelector('.pnq-textstyle-cancel').addEventListener('click', cancelEditor);
    elm.classList.add('pnq-text-editing');
  }

  function block(label, inner) {
    return '<div class="pnq-textstyle-block"><div class="pnq-textstyle-blabel">' + label + '</div>' +
      '<div class="pnq-textstyle-brow">' + inner + '</div></div>';
  }

  // live preview (no persist) while sliders/fields move
  function applyEditor() {
    if (!editor || editorId == null) return;
    var elm = document.getElementById('customText' + editorId);
    if (!elm) { closeStyleEditor(); return; }
    elm.setAttribute('name', $q('#pnq-ts-name', editor).value);
    elm.style.zIndex = 1000 + (parseInt($q('#pnq-ts-z', editor).value, 10) || 0);
    applyRotation(elm, parseInt($q('#pnq-ts-rot', editor).value, 10) || 0);
  }
  function saveEditor() {
    applyEditor();
    var elm = document.getElementById('customText' + editorId);
    if (elm) persistText(elm);
    closeStyleEditor();
  }
  function cancelEditor() {
    var elm = document.getElementById('customText' + editorId);
    if (elm && orig) {
      elm.setAttribute('name', orig.name);
      elm.style.zIndex = 1000 + orig.z;
      applyRotation(elm, orig.rot);
    }
    closeStyleEditor();
  }
  function closeStyleEditor() {
    if (editorId != null) {
      var e = document.getElementById('customText' + editorId);
      if (e) e.classList.remove('pnq-text-editing');
    }
    if (editor) { editor.remove(); editor = null; }
    editorId = null; orig = null;
  }

  // right-click → Edit for text objects → our Style Editor (block native form)
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('.action-textobjectedit');
    if (!a) return;
    var id = a.getAttribute('data-path');
    if (!isText(id)) return;                      // shapes handled by pnetlab-shape.js
    e.preventDefault(); e.stopImmediatePropagation();
    var cm = document.getElementById('context-menu'); if (cm) cm.remove();
    openStyleEditor(id);
  }, true);

})();
