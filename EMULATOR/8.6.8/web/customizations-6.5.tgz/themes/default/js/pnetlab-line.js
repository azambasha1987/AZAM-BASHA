/* =====================================================================
 * pnetlab-line.js — EVE-NG-style "Add Line" workflow (2026-06-03)
 *
 * Replaces PNetLab's clunky 11-field `.line_ctl_frame` top bar with EVE-NG
 * Pro's clean "Add Line" modal: Live Preview + Arrow Style + Label + Width +
 * Color + Line Style + Save/Cancel. Right-click a line -> Edit Style / Delete.
 *
 * No PNetLab core edits. We intercept the native `.action-lineadd` /
 * `.action-lineedit` clicks (capture phase, same pattern as pnetlab-shape.js /
 * pnetlab-text.js) so the native createLine()+bar never runs, and instead drive
 * the line REST API directly:
 *     POST /api/labs/session/line/{add,edit,delete}  -> updateData + printTopology
 * The stored object shape (validated on .148) is:
 *   {id,width,linestyle:"Straight",paintstyle,color,label,startsym,endsym,
 *    x1,x2,y1,y2,linecfg:"{}"}
 *   paintstyle in {solid,dashed,dotted,dotdash};  start/endsym in {"",arrow,dot,square}
 * We POST only on Save, so Cancel is a no-op (nothing is pre-created).
 * ===================================================================== */
(function pnqLineWorkflow(){
  "use strict";

  var ARROWS = {
    line:   { startsym:"",      endsym:""      },
    single: { startsym:"",      endsym:"arrow" },
    double: { startsym:"arrow", endsym:"arrow" }
  };
  var DASH = { solid:"", dashed:"8,6" };       // for the live preview only

  var state = null;   // { mode:'add'|'edit', id, x1,y1,x2,y2 }

  /* ---------- helpers ---------- */
  function zoom(){ try { return (typeof getZoomLab==="function" ? getZoomLab() : 100)/100 || 1; } catch(e){ return 1; } }
  function newId(){ try { if (typeof makeId==="function") return String(makeId()); } catch(e){} return String(Date.now())+String(Math.floor(Math.random()*1000)); }
  function api(action, body){
    return fetch("/api/labs/session/line/"+action, {
      method:"POST", headers:{"Content-Type":"application/json"}, credentials:"same-origin",
      body:JSON.stringify(body)
    }).then(function(r){ return r.json(); });
  }
  function repaint(res){
    try { if (res && res.update && App.topology) App.topology.updateData(res.update); } catch(e){}
    try { if (App.topology) App.topology.printTopology(); } catch(e){}
  }
  function arrowKeyFor(startsym, endsym){
    if (startsym==="arrow" && endsym==="arrow") return "double";
    if (endsym==="arrow") return "single";
    return "line";
  }

  /* ---------- the modal (built once, reused) ---------- */
  var dom = null;
  function buildModal(){
    if (dom) return dom;
    var ov = document.createElement("div");
    ov.className = "pnq-line-overlay";
    ov.innerHTML =
      '<div class="pnq-line-modal" role="dialog" aria-label="Add Line">'+
        '<div class="pnq-line-title">Add Line</div>'+
        '<div class="pnq-line-field"><label>Live Preview</label>'+
          '<div class="pnq-line-preview"><svg viewBox="0 0 460 60" preserveAspectRatio="xMidYMid meet">'+
            '<defs>'+
              '<marker id="pnqLineArrowEnd" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z"></path></marker>'+
              '<marker id="pnqLineArrowStart" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z"></path></marker>'+
            '</defs>'+
            '<path class="pnq-line-prevpath" d="M 30 30 L 430 30" fill="none"></path>'+
            '<g class="pnq-line-prevlabel" style="display:none"><rect rx="3"></rect><text x="0" y="0" text-anchor="middle" dominant-baseline="central"></text></g>'+
          '</svg></div>'+
        '</div>'+
        '<div class="pnq-line-field"><label>Arrow Style</label>'+
          '<select class="pnq-line-arrow">'+
            '<option value="line">Line</option>'+
            '<option value="single">Single Arrow</option>'+
            '<option value="double">Double Arrows</option>'+
          '</select></div>'+
        '<div class="pnq-line-row">'+
          '<div class="pnq-line-field"><label>Label</label><input type="text" class="pnq-line-label" name="pnq_line_label" placeholder="" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" readonly></div>'+
          '<div class="pnq-line-field"><label>Width</label><input type="number" class="pnq-line-width" min="1" max="20" value="2" autocomplete="off"></div>'+
        '</div>'+
        '<div class="pnq-line-row">'+
          '<div class="pnq-line-field pnq-line-colorfield"><label>Color</label>'+
            '<div class="pnq-line-colorwrap"><span class="pnq-line-hash">#</span>'+
              '<input type="text" class="pnq-line-colorhex" value="000000" maxlength="6" autocomplete="off" spellcheck="false">'+
              '<button type="button" class="pnq-line-swatch" aria-label="Pick colour"></button>'+
              '<div class="pnq-line-cpop" hidden></div></div></div>'+
          '<div class="pnq-line-field"><label>Line Style</label>'+
            '<select class="pnq-line-style"><option value="solid">Solid</option><option value="dashed">Dashed</option></select></div>'+
        '</div>'+
        '<div class="pnq-line-actions">'+
          '<button type="button" class="pnq-line-save">SAVE</button>'+
          '<button type="button" class="pnq-line-cancel">CANCEL</button>'+
        '</div>'+
      '</div>';
    document.body.appendChild(ov);

    dom = {
      ov: ov,
      modal: ov.querySelector(".pnq-line-modal"),
      title: ov.querySelector(".pnq-line-title"),
      arrow: ov.querySelector(".pnq-line-arrow"),
      label: ov.querySelector(".pnq-line-label"),
      width: ov.querySelector(".pnq-line-width"),
      hex:   ov.querySelector(".pnq-line-colorhex"),
      swatch:ov.querySelector(".pnq-line-swatch"),
      cpop:  ov.querySelector(".pnq-line-cpop"),
      style: ov.querySelector(".pnq-line-style"),
      save:  ov.querySelector(".pnq-line-save"),
      cancel:ov.querySelector(".pnq-line-cancel"),
      prevPath: ov.querySelector(".pnq-line-prevpath"),
      prevLabelG: ov.querySelector(".pnq-line-prevlabel"),
      prevRect: ov.querySelector(".pnq-line-prevlabel rect"),
      prevText: ov.querySelector(".pnq-line-prevlabel text")
    };

    // wiring
    ["input","change"].forEach(function(ev){
      [dom.arrow,dom.label,dom.width,dom.style].forEach(function(el){ el.addEventListener(ev, refreshPreview); });
    });
    dom.hex.addEventListener("input", function(){
      var v = dom.hex.value.replace(/[^0-9a-fA-F]/g,"").slice(0,6); dom.hex.value=v;
      syncSwatch(); refreshPreview();
    });
    // EVE-style in-modal colour popover — replaces the native <input type=color>,
    // whose OS popup opened below the swatch and bled off the bottom of the screen.
    var PALETTE = ["#000000","#3c708a","#1b6fb3","#1b7e3c","#d62828","#e0a52e",
                   "#7b2cbf","#00838f","#5f6b7a","#9aa0a6","#ffffff","#0066aa",
                   "#c00001","#ff8800","#2e7d32","#6d4c41","#455a64","#e91e63"];
    PALETTE.forEach(function(c){
      var sw=document.createElement("button"); sw.type="button"; sw.className="pnq-line-cpop-sw";
      sw.style.background=c; sw.title=c;
      sw.addEventListener("click", function(e){ e.stopPropagation(); setColor(c); closePop(); });
      dom.cpop.appendChild(sw);
    });
    dom.swatch.addEventListener("click", function(e){ e.stopPropagation(); dom.cpop.hidden=!dom.cpop.hidden; });
    dom.cpop.addEventListener("mousedown", function(e){ e.stopPropagation(); });
    document.addEventListener("click", function(){ closePop(); });
    // anti-autofill: the label is readonly until the user actually focuses it
    // (stops Chrome from injecting the saved username, e.g. "admin").
    dom.label.addEventListener("focus", function(){ dom.label.removeAttribute("readonly"); });
    dom.save.addEventListener("click", onSave);
    dom.cancel.addEventListener("click", close);
    ov.addEventListener("mousedown", function(e){ if (e.target===ov) close(); });
    document.addEventListener("keydown", function(e){ if (ov.classList.contains("pnq-open") && e.key==="Escape") close(); });
    return dom;
  }

  function syncSwatch(){
    var v = dom.hex.value.replace(/[^0-9a-fA-F]/g,"").slice(0,6);
    if (v.length===6) dom.swatch.style.background = "#"+v;
  }
  function setColor(c){ dom.hex.value = c.replace("#",""); syncSwatch(); refreshPreview(); }
  function closePop(){ if (dom && dom.cpop) dom.cpop.hidden = true; }

  function vals(){
    var ar = ARROWS[dom.arrow.value] || ARROWS.line;
    var hex = dom.hex.value.replace(/[^0-9a-fA-F]/g,"").slice(0,6);
    if (hex.length!==6) hex = "000000";
    return {
      width: String(Math.max(1, parseInt(dom.width.value,10)||2)),
      paintstyle: dom.style.value,
      color: "#"+hex,
      label: dom.label.value || "",
      startsym: ar.startsym,
      endsym: ar.endsym
    };
  }

  function refreshPreview(){
    var v = vals();
    var p = dom.prevPath;
    p.setAttribute("stroke", v.color);
    p.setAttribute("stroke-width", v.width);
    p.setAttribute("stroke-dasharray", DASH[v.paintstyle]||"");
    p.setAttribute("marker-end",   v.endsym==="arrow"   ? "url(#pnqLineArrowEnd)"   : "");
    p.setAttribute("marker-start", v.startsym==="arrow" ? "url(#pnqLineArrowStart)" : "");
    // arrowhead colour follows the line
    dom.modal.querySelectorAll("#pnqLineArrowEnd path,#pnqLineArrowStart path").forEach(function(m){ m.setAttribute("fill", v.color); });
    // label chip
    if (v.label){
      dom.prevText.textContent = v.label;
      dom.prevText.setAttribute("x","230"); dom.prevText.setAttribute("y","30");
      dom.prevText.setAttribute("fill","#1d1d1f");
      var w = Math.max(28, v.label.length*8 + 14);
      dom.prevRect.setAttribute("x", String(230 - w/2));
      dom.prevRect.setAttribute("y","18"); dom.prevRect.setAttribute("width", String(w)); dom.prevRect.setAttribute("height","24");
      dom.prevRect.setAttribute("fill","#ffffff"); dom.prevRect.setAttribute("stroke", v.color);
      dom.prevLabelG.style.display="";
    } else {
      dom.prevLabelG.style.display="none";
    }
  }

  function openModal(mode, prefill){
    buildModal();
    state = { mode:mode };
    dom.title.textContent = mode==="edit" ? "Edit Line" : "Add Line";
    dom.save.textContent  = "SAVE";
    var d = prefill || {};
    dom.width.value = (d.width && d.width!=="") ? d.width : "2";
    dom.style.value = (d.paintstyle==="dashed") ? "dashed" : "solid";
    var hex = (d.color||"#000000").replace("#","");
    if (!/^[0-9a-fA-F]{6}$/.test(hex)) hex="000000";
    dom.hex.value = hex; syncSwatch();
    dom.label.value = d.label || "";
    dom.label.setAttribute("readonly","readonly");   // re-arm anti-autofill each open
    dom.arrow.value = arrowKeyFor(d.startsym, d.endsym);
    closePop();
    refreshPreview();
    dom.ov.classList.add("pnq-open");
  }

  function close(){
    if (dom){ dom.ov.classList.remove("pnq-open"); closePop(); }
    state = null;
  }

  function onSave(){
    if (!state) return;
    var v = vals();
    if (state.mode==="add"){
      var id = newId();
      var data = {
        id:id, width:v.width, linestyle:"Straight", paintstyle:v.paintstyle,
        color:v.color, label:v.label, startsym:v.startsym, endsym:v.endsym,
        x1:String(state.x1), x2:String(state.x2), y1:String(state.y1), y2:String(state.y2),
        linecfg:"{}"
      };
      api("add", {data:data}).then(repaint).catch(function(e){ console.log("line add error", e); });
    } else if (state.mode==="edit" && state.id){
      var cur = (App.topology && App.topology.lines && App.topology.lines[state.id]) || {};
      var base = cur.params || cur;
      var data2 = Object.assign({}, base, {
        id:state.id, width:v.width, paintstyle:v.paintstyle, color:v.color,
        label:v.label, startsym:v.startsym, endsym:v.endsym, linestyle:"Straight"
      });
      delete data2.params;
      api("edit", {data:data2}).then(repaint).catch(function(e){ console.log("line edit error", e); });
    }
    close();
  }

  /* ---------- locate the line id from the right-clicked connection ---------- */
  function lineIdFromConn(conn){
    if (!conn) return null;
    // jsPlumb connection -> its svg canvas carries class "... sym_<id>"
    try {
      var el = conn.canvas || conn.connector && conn.connector.canvas;
      var cls = el && (el.getAttribute ? el.getAttribute("class") : el.className) || "";
      var m = /sym_(\d+)/.exec(cls);
      if (m) return m[1];
    } catch(e){}
    // fallback: conn.id may contain the numeric id
    try { var m2 = /(\d{6,})/.exec(String(conn.id||"")); if (m2) return m2[1]; } catch(e){}
    return null;
  }

  /* ---------- intercept native line add / edit (capture phase) ---------- */
  document.addEventListener("click", function(e){
    var add = e.target.closest && e.target.closest(".action-lineadd");
    var edt = e.target.closest && e.target.closest(".action-lineedit");
    if (!add && !edt) return;
    // stop PNetLab's own delegated (bubble-phase) handler -> no native bar
    e.preventDefault();
    e.stopImmediatePropagation();
    var ctx = document.getElementById("context-menu"); if (ctx) ctx.remove();

    if (add){
      var z = zoom();
      var cc = null; try { cc = window.jQuery && jQuery("#lab-viewport").data("contextClickXY"); } catch(_){}
      var x1, y1;
      if (cc){ x1 = Math.round(cc.x / z); y1 = Math.round(cc.y / z); }
      else { x1 = Math.round((window.innerWidth*0.40)/z); y1 = Math.round((window.innerHeight*0.40)/z); }
      openModal("add", null);
      state.x1 = x1; state.y1 = y1; state.x2 = x1 + 200; state.y2 = y1;
    } else {
      var id = lineIdFromConn(window.connToDel);
      var rec = id && App.topology && App.topology.lines && App.topology.lines[id];
      var d = rec ? (rec.params || rec) : {};
      openModal("edit", d);
      state.id = id;
    }
  }, true);

  /* ---------- relabel the line right-click menu: "Connection"->"Line", "Edit"->"Edit Style" ---------- */
  function tidyLineMenu(menu){
    if (!menu) return;
    var editA = menu.querySelector(".action-lineedit");
    if (!editA) return;                              // only the custom-line connection menu
    // relabel Edit -> Edit Style (keep the icon)
    var txt = editA.childNodes;
    for (var i=0;i<txt.length;i++){ if (txt[i].nodeType===3 && /\S/.test(txt[i].textContent)) txt[i].textContent = " Edit Style"; }
    // retitle the header "Connection" -> "Line"
    var hdr = menu.querySelector("#menu_title, .dropdown-header, #menu_title_left");
    if (hdr && /connection/i.test(hdr.textContent)) hdr.textContent = "Line";
  }
  var mo = new MutationObserver(function(muts){
    for (var i=0;i<muts.length;i++){
      var ad = muts[i].addedNodes;
      for (var j=0;j<ad.length;j++){
        var n = ad[j]; if (n.nodeType!==1) continue;
        if (n.id==="context-menu" || (n.querySelector && n.querySelector(".action-lineedit"))) tidyLineMenu(n.id==="context-menu"?n:n);
        if (n.id==="context-menu") tidyLineMenu(n);
      }
    }
    // also catch the case where #context-menu already exists and content swapped
    var cm = document.getElementById("context-menu");
    if (cm && cm.querySelector(".action-lineedit")) tidyLineMenu(cm);
  });
  try { mo.observe(document.body, {childList:true, subtree:true}); } catch(e){}

})();
